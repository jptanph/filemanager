<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/lib/Common.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/model/model.class.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/common/common.function.php');

class Setup_thedaychk
{
	private $_oSmarty;
	private $_oModel;
	private $_sTemplatesFolder;
	private $_iUserIdx;
	private $_sPrefix;
	
	public function __construct()
	{
		$this->_oSmarty = new Smarty();
		$this->_oModel = new Model();
		$this->_iUserIdx = $this->_getUserIdx();
		$this->_sTemplatesFolder = 'templates/';
		$this->_sPrefix = 'pg_thedaychk_';
		$this->_initEnvironment();
		$this->_requestHandler();
	}
	
	private function _initEnvironment()
	{
		$this->_setVariable( 'sScriptCrossDomain' , CAFE24_CROSS_DOMAIN );	
		$this->_setVariable( 'sPluginRoot' , SERVER_BASE_URL);
		$this->_setVariable( 'sPluginUrl' , PLUGIN_URL);
		
		$this->_setVariable( 'sJqueryLib' , SERVER_JQUERYJS_URL);
		$this->_setVariable( 'sJqueryUILib' , SERVER_JQUERYUIJS_URL);
		$this->_setVariable( 'sJqueryUICSS' , SERVER_JQUERYUICSS_URL);
		$this->_setVariable( 'sTemplate' , $this->_checkTempate());
		$this->_setVariable( 'sPrefix' , $this->_sPrefix);
		$this->_setVariable( 'sStatus' , getVar('status'));
	}
	
	private function _getUserIdx()
	{
		return $this->_oModel->getUserIdx(PLUGIN_USER_ID);
	}
	
	private function _requestHandler()
	{
		switch(getVar('action'))
		{
			case'savetemplate': $this->_updateTempate();
			break;
			
			default:$this->_setTemplate('setup.tpl');
		}
	}
	
	private function _setVariable($sVarName,$sVarValue)
	{
		$this->_oSmarty->assign( $sVarName , $sVarValue);
	}
	
	private function _setTemplate($sTemplate)
	{
		$this->_oSmarty->display($this->_sTemplatesFolder . $sTemplate);
	}
	
	private function _checkTempate()
	{
		if($this->_oModel->getTemplate($this->_iUserIdx)==''){
			echo $this->_oModel->insertTemplate(getVar('template'),$this->_iUserIdx);
		}else{
			return $this->_oModel->getTemplate($this->_iUserIdx);
		}
	}
	
	private function _updateTempate()
	{
		$this->_oModel->updateTemplate(getVar('template'),$this->_iUserIdx);
	}
}

$setupThedaychk = new Setup_thedaychk();