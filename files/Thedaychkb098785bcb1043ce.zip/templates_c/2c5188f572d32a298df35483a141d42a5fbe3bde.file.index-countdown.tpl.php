<?php /* Smarty version Smarty-3.0.6, created on 2011-10-07 12:04:17
         compiled from "templates/index-countdown.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15100126724e8e7a41832835-12804502%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c5188f572d32a298df35483a141d42a5fbe3bde' => 
    array (
      0 => 'templates/index-countdown.tpl',
      1 => 1317960256,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15100126724e8e7a41832835-12804502',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

<?php if (!$_smarty_tpl->getVariable('aResult')->value){?>

<?php }else{ ?>

	<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aResult')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
		<input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_date'];?>
" id="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
start_date" /></p>
	<?php }} ?>
	<script>
		$(function(){
			Plugin_Thedaychk_front.execStartTimer();
		})
	</script>
	<div id="pg_thedaychk_timer"></div>
<?php }?>