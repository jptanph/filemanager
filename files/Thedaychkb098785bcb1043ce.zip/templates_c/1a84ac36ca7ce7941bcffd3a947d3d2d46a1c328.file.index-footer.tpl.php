<?php /* Smarty version Smarty-3.0.6, created on 2011-10-11 08:06:57
         compiled from "templates/index-footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13890112444e9388a176b834-84056438%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a84ac36ca7ce7941bcffd3a947d3d2d46a1c328' => 
    array (
      0 => 'templates/index-footer.tpl',
      1 => 1318291616,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13890112444e9388a176b834-84056438',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>