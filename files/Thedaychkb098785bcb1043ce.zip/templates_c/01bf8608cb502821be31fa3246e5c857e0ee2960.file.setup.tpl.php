<?php /* Smarty version Smarty-3.0.6, created on 2011-10-11 10:19:28
         compiled from "templates/setup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13749126504e93a7b0c73587-25837793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01bf8608cb502821be31fa3246e5c857e0ee2960' => 
    array (
      0 => 'templates/setup.tpl',
      1 => 1318294215,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13749126504e93a7b0c73587-25837793',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator</title>
<link href="css/plugin.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="js/thedaychk.admin.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryLib')->value;?>
"></script>
<!--[if IE 7]>
<link href="css/ie7.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
<!--[if lte IE 7]>
<link href="css/lte_ie7.css" rel="stylesheet" type="text/css" media="screen" />
<script defer type="text/javascript" language="Javascript" src="pngfix.js"></script>
<![endif]-->
<!--[if IE 6]>
<link href="css/ie6.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
</head>

<body>
<?php echo $_smarty_tpl->getVariable('sScriptCrossDomain')->value;?>

<!-- message box -->			
<div class="msg_suc_box" id="message_save" <?php if ($_smarty_tpl->getVariable('sStatus')->value=='save'){?><?php }else{ ?>style="display:none"<?php }?>>
	<p><span>Settings has been saved successfully.</span></p>
</div>

<!-- message box -->			
<div class="msg_suc_box" id="message_reset" <?php if ($_smarty_tpl->getVariable('sStatus')->value=='restore'){?><?php }else{ ?>style="display:none"<?php }?>>
	<p><span>Settings has been reset successfully.</span></p>
</div>


<h3 class="extension_plugin_name">The Day Check</h3>
<h3>Settings</h3>
<p>Plugin ID: The Day Check</p>
<p class="require"><span class="neccesary">*</span> Required</p>
<!-- input area -->			
<table border="1" cellspacing="0" class="table_input_vr">
<colgroup>
	<col width="115px" />
	<col width="*" />
</colgroup>
<tr>
	<th><label for="template_setting">Template</label></th>
	<td>	
		<div class="template_setting" id="template_setting">
			<div class="template_icon">
			<input type="radio" name="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
template" value="blue" id="blue" <?php if ($_smarty_tpl->getVariable('sTemplate')->value==''||$_smarty_tpl->getVariable('sTemplate')->value=='blue'){?>checked="checked"<?php }?> class="input_rdo" /> 
			<label for="blue">Blue</label>
			<label for="blue"><img src="images/u106_original.png" alt="Original Template Blue" /></label>
			</div>
			<div class="template_icon">
				<input type="radio"  name="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
template" value="gray" id="gray" class="input_rdo"   <?php if ($_smarty_tpl->getVariable('sTemplate')->value=='gray'){?>checked="checked"<?php }?>/> <label for="gray">Gray</label>
				<label for="gray"><img src="images/u108_original.png" alt="Original Template Gray" /></label>
			</div>
		</div>
	</td>
</tr>	
</table>
<script type="text/javascript"> 
//<![CDATA[
	function toggle(no) { 
	  var obj = document.getElementById('item' + no); 
	  if (obj.style.display == '' || !obj.style.display) obj.style.display = 'none'; 
	  else obj.style.display = ''; 
	} 
//]]>
</script> 

<!--<div class="stit_vr_wide">
	<h3 class="add_h"><a href="#item1" onclick="toggle(1);" title="Search Engine Optimization">Search Engine Optimization <span class="vdn">▼▲</span></a></h3>
	<a href="#" class="add_link" title="Learn more">Learn More</a>
</div>

<table border="1" cellspacing="0" id="item1" class="table_input_vr tbl_zero" style="display:none">
<colgroup>
	<col width="115px" />
	<col width="*" />
</colgroup>
<tr>
	<th><label for="title">Title</label></th>
	<td><input type="text" id="title" class="fix" value="Article" /></td>
</tr>
<tr>
	<th><label for="url_key">URL Key</label></th>
	<td><input type="text" id="url_key" class="fix" value="Article" /></td>
</tr>
<tr>
	<th><label for="description">Description</label></th>
	<td><textarea cols="30" rows="5" id="description"></textarea></td>
</tr>
<tr>
	<th><label for="keywords">Keywords</label></th>
	<td>
		<input type="text" id="keywords" />
		<span class="annonce_vr">Use commas(,) to seperate keywords.</span>
	</td>
</tr>
<tr>
	<th><label for="robots">Robots</label></th>
	<td>
		<select id="robots" title="select robots type">
			<option>All</option>
			<option>Index, Follow</option>
			<option>NoIndex, Follow</option>
			<option>Index, NoFollow</option>
			<option>NoIndex, NoFollow</option>
		</select>
	</td>
</tr>
<tr>
	<th><label for="other">Other Header Scripts</label></th>
	<td><textarea cols="30" rows="5" id="other"></textarea></td>
</tr>
</table>	-->		
<!-- // input area -->	

<script type="text/javascript"> 
//<![CDATA[
function chk_validate (){
	document.getElementById('module_label_wrap').className='warn_border';
}
//]]>
</script>
<div class="tbl_lb_wide_btn">
	<a href="#" class="btn_apply" title="Save changes" onclick="Plugin_Thedaychk_admin.execSaveTemplate();">Save</a>
	<a href="#" class="add_link" title="Reset to default"  onclick="Plugin_Thedaychk_admin.execReset();">Reset to Default</a>
</div>
<input type="hidden" value="<?php echo $_smarty_tpl->getVariable('sPluginUrl')->value;?>
" id="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
server_url"/>
<script type="text/javascript">
	$(function(){
		$("#message_reset").fadeOut(2000)
		$("#message_save").fadeOut(2000)
	})
</script>
</body>
</html>