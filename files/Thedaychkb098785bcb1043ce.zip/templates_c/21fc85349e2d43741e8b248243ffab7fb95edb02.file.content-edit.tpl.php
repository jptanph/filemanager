<?php /* Smarty version Smarty-3.0.6, created on 2011-10-10 14:19:35
         compiled from "templates/content-edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:232351504e928e77954d57-37870298%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '21fc85349e2d43741e8b248243ffab7fb95edb02' => 
    array (
      0 => 'templates/content-edit.tpl',
      1 => 1318227573,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '232351504e928e77954d57-37870298',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator</title>
<link href="<?php echo $_smarty_tpl->getVariable('sJqueryUICSS')->value;?>
" rel="stylesheet" type="text/css" media="screen" />
<link href="css/plugin.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="js/thedaychk.admin.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryLib')->value;?>
"></script>	
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryUILib')->value;?>
"></script>	
<script type="text/javascript" src="js/jquery.validate.js"></script>	


<!--[if IE 7]>
<link href="css/ie7.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
<!--[if lte IE 7]>
<link href="css/lte_ie7.css" rel="stylesheet" type="text/css" media="screen" />
<script defer type="text/javascript" language="Javascript" src="pngfix.js"></script>
<![endif]-->
<!--[if IE 6]>
<link href="css/ie6.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
</head>

<body>
<?php echo $_smarty_tpl->getVariable('sScriptCrossDomain')->value;?>

<!-- message box -->			
<div class="msg_suc_box" id="message_save" <?php if ($_smarty_tpl->getVariable('sStatus')->value=='update'){?><?php }else{ ?>style="display:none"<?php }?>>
	<p><span>Settings has been updated successfully.</span></p>
</div>


<h3 class="extension_plugin_name">The Day Check</h3>
<h3>Add New Day Check</h3>
<p class="require"><span class="neccesary">*</span> Required</p>
<!-- input area -->			

<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aResult')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
<input type="hidden"  name="event_idx" id="event_idx" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
"/>
<table border="1" cellspacing="0" class="table_input_vr">
<colgroup>
	<col width="115px" />
	<col width="*" />
</colgroup>
<tr>
	<th><label for="clock_location1">Date</label></th>
	<td style="padding:0;">
		<table border="0" cellspacing="2" celllpaddding="2">
			<tr>
				<td><span class="neccesary">*</span><label for="scheduler_date">Date:</label></td>
				<td><p><input type="text" readonly="true"  value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_date'];?>
" class="fix" id="schedule_date" /></p></td>
				<td><a href="#"><img src="images/calendar_icon.png" /></a></td>
				<td><!--<label for="scheduler_time">Time:</label>--></td>
				<td>
					<!--
					<select id="scheduler_time" class="select_option">
						<option value="00:00">00:00</option>
						<option value="01:00">01:00</option>
						<option value="02:00">02:00</option>
						<option value="03:00">03:00</option>
						<option value="04:00">04:00</option>
						<option value="05:00">05:00</option>
						<option value="06:00">06:00</option>
						<option value="07:00">07:00</option>
						<option value="08:00">08:00</option>
						<option value="09:00">09:00</option>
						<option value="10:00">10:00</option>
						<option value="11:00">11:00</option>
						<option value="12:00" selected="selected">12:00</option>
						<option value="13:00">13:00</option>
						<option value="14:00">14:00</option>
						<option value="15:00">15:00</option>
						<option value="16:00">16:00</option>
						<option value="17:00">17:00</option>
						<option value="18:00">18:00</option>
						<option value="19:00">19:00</option>
						<option value="20:00">20:00</option>
						<option value="21:00">21:00</option>
						<option value="22:00">22:00</option>
						<option value="23:00">23:00</option>
						<option value="24:00">24:00</option>
					</select>
				-->
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr><th><label for="textarea_memo">Event Title</label></th><td><span class="neccesary">*</span><input type="text" name="event_title" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_title'];?>
" id="event_title" class="fix2" maxlength="25" /></td></tr>
<tr><th><label for="textarea_memo">Mark Special Event</label></th><td><span class="neccesary">&nbsp;&nbsp;</span><input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['rows']->value['ptd_specialevent_flag']==1){?>checked="checked<?php }?>"  id="event_special" value="" class="input_rdo" /> 
</td></tr>
<tr><th><label for="textarea_memo">Recursive</label></th><td><span class="neccesary">&nbsp;&nbsp;</span><input type="checkbox" <?php if ($_smarty_tpl->tpl_vars['rows']->value['ptd_recursive_flag']==1){?>checked="checked"<?php }?>  title="" id="event_recursive" class="input_chk fix2"/>
</td></tr>
</table>
<?php }} ?>

<script type="text/javascript"> 
//<![CDATA[
	function toggle(no) { 
	  var obj = document.getElementById('item' + no); 
	  if (obj.style.display == '' || !obj.style.display) obj.style.display = 'none'; 
	  else obj.style.display = ''; 
	} 
//]]>
</script> 


<!-- // input area -->	

<script type="text/javascript"> 
//<![CDATA[
function chk_validate (){
	document.getElementById('module_label_wrap').className='warn_border';
}
//]]>
</script>
<div class="tbl_lb_wide_btn">
	<a href="#" class="btn_apply" title="Save changes"  onclick="Plugin_Thedaychk_admin.execUpdate();">Save</a>
	<a href="content.php" class="add_link" title="Return to Day Check">Return to Day Check</a>
</div>
<script type="text/javascript">
	$(function(){
		$("#schedule_date").datepicker({ dateFormat: 'yy-mm-dd' });
		$("#message_reset").fadeOut(2000)
		$("#message_save").fadeOut(2000)
	});
</script>
</body>
</html>