<?php /* Smarty version Smarty-3.0.6, created on 2011-10-11 14:53:54
         compiled from "templates/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8325548074e93e802ec7309-52935403%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd45ffb6734c4fc6fe641f785fde707a0e34bbf00' => 
    array (
      0 => 'templates/content.tpl',
      1 => 1318316034,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8325548074e93e802ec7309-52935403',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator</title>
<link href="css/plugin.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="js/thedaychk.admin.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryLib')->value;?>
"></script>	
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sPluginRoot')->value;?>
lib/js/popup.js"></script>	
<!--[if IE 7]>
<link href="css/ie7.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
<!--[if lte IE 7]>
<link href="css/lte_ie7.css" rel="stylesheet" type="text/css" media="screen" />
<script defer type="text/javascript" language="Javascript" src="pngfix.js"></script>
<![endif]-->
<!--[if IE 6]>
<link href="css/ie6.css" rel="stylesheet" type="text/css" media="screen" />	
<![endif]-->
</head>
<body>
<?php echo $_smarty_tpl->getVariable('sScriptCrossDomain')->value;?>

<div class="msg_warn_box"  id="message_delete" <?php if ($_smarty_tpl->getVariable('sStatus')->value=='delete'){?><?php }else{ ?>style="display:none"<?php }?>>
	<p><span>Deleted successfully.</span></p>
</div>

<div class="msg_suc_box" id="message_save" <?php if ($_smarty_tpl->getVariable('sStatus')->value=='save'){?><?php }else{ ?>style="display:none"<?php }?>>
	<p><span>Settings has been saved successfully.</span></p>
</div>

<div id="no_del" style="display:none" title="Delete Event">
	<center>No event selected.</center>
</div>

<div id="confirm_del" style="display:none" title="Delete Event">
	<center>Are you sure you want to delete this event?<br /><br />
		<a href="#none" class="btn_nor_01 btn_width_st1"  onclick="Plugin_Thedaychk_admin.execDeleteList();" title="Delete Event">Delete</a>
	</center>
</div>

<br />	
<div class="table_header_area">
	<ul class="row_1">
		<li>
			<?php if ($_smarty_tpl->getVariable('iCount')->value<6){?><a href="#none" class="btn_nor_01 btn_width_st1" title="Add selected schedule" onclick="Plugin_Thedaychk_admin.execAdd();">Add</a><?php }?>
			<a href="#none" class="btn_nor_01 btn_width_st1" title="Delete selected schedule"  onClick="Plugin_Thedaychk_admin.execDelete()">Delete</a>
			<a href="#none" class="btn_nor_01 btn_width_st1" title="Save selected schedule" onClick="Plugin_Thedaychk_admin.execSaveContent()">Save</a>
		</li>
		
	</ul>
</div>
<!-- // table header -->
<!-- table horizontal -->
<form>
<table border="1" cellpadding="0" cellspacing="0" class="table_hor_02">
<colgroup>
	<col width="44px" />
	<col width="48px" />
	<col/>
	<col  />
	<col/>				
	<col />		
</colgroup>
<thead>
<tr>
	<th>No.</th>
	<th class="chk"><input type="checkbox" title="" onClick="Plugin_Thedaychk_admin.execSelectAll()" class="input_chk" /></th>
	<th><a href="#" onClick="Plugin_Thedaychk_admin.execSort('ptd_event_date')"  <?php if ($_smarty_tpl->getVariable('sSortInput')->value==''||$_smarty_tpl->getVariable('sSortInput')->value=='asc'){?><?php }elseif($_smarty_tpl->getVariable('sSortInput')->value=='des'&$_smarty_tpl->getVariable('sSortField')->value=='ptd_event_date'){?>class="des"<?php }?> >Date</a></th>				
	<th><a href="#" onClick="Plugin_Thedaychk_admin.execSort('ptd_event_title')" <?php if ($_smarty_tpl->getVariable('sSortInput')->value==''||$_smarty_tpl->getVariable('sSortInput')->value=='asc'){?><?php }elseif($_smarty_tpl->getVariable('sSortInput')->value=='des'&$_smarty_tpl->getVariable('sSortField')->value=='ptd_event_title'){?>class="des"<?php }?> >Event Title</a></th>	
	<th>Mark Special Event</th>	
	<th>Recursive</th>	
</tr>
</thead>
<tbody>
	<?php if (!$_smarty_tpl->getVariable('aResult')->value){?>
	<tr>
		<td colspan="6" class="not_fnd">There's no content.</td>
	</tr>
	<?php }else{ ?>
		<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aResult')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
			<tr onmouseover="this.className='over'" onmouseout="this.className=''">
				<td><?php echo $_smarty_tpl->tpl_vars['rows']->value['row_no'];?>
</td>
				<td><input type="checkbox" title="" name="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
check" class="input_chk" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
" /></td>
				<td><a href="#"  onclick="Plugin_Thedaychk_admin.execEdit(<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
);"><?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_date'];?>
</a></td>
				<td><a href="#"  onclick="Plugin_Thedaychk_admin.execEdit(<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
);"><?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_title'];?>
</a></td>			
				<td><input class="input_chk" type="radio" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
"  name="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
event_special" <?php if ($_smarty_tpl->tpl_vars['rows']->value['ptd_specialevent_flag']==1){?>checked="checked"<?php }?>></td>
				<td><input type="checkbox" name="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
event_recursive" value="<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_idx'];?>
" title="" class="input_chk" <?php if ($_smarty_tpl->tpl_vars['rows']->value['ptd_recursive_flag']==1){?>checked="checked"<?php }?> /></td>		
			</tr>
		<?php }} ?>
	<?php }?>

</tbody>
</table>
</form>
<!-- // table horizontal -->
<div class="table_header_area">
	<ul class="row_2">
		<!--<li>
			<select>
				<option>Select Action</option>
				<option>Expected</option>
				<option>Finished</option>
				<option>Delete</option>
				<option>Move</option>
			</select>
			<a href="#none" class="btn_nor_01 btn_width_st1" title="Apply selected action">Apply</a>	
		</li>-->
		<li>
			<a href="#none" class="btn_nor_01 btn_width_st1" onClick="Plugin_Thedaychk_admin.execDelete()" title="Delete selected schedule">Delete</a>
		</li>
		<li class="show">
			<?php if ($_smarty_tpl->getVariable('iCount')->value<6){?><a href="#" class="btn_nor_01 btn_width_st2" title="Add New Schedule" onclick="Plugin_Thedaychk_admin.execAdd();">Add</a><?php }?>
		</li>
	</ul>
</div>


<!-- pagination -->
<!--
<div class="pagination">				
	<span title="Previous">prev</span>
	<a href="#none" class="current">1</a>
	<a href="#none" class="num">2</a>
	<a href="#none" class="num">3</a>
	<a href="#none" class="num">4</a>
	<a href="#none" class="num">5</a>
	<a href="#none" class="num">6</a>
	<a href="#none" class="num">7</a> ...
	<a href="#none" class="num">41</a>
	<a href="#none" class="activity" title="Next">next</a>				
</div>
-->
<!-- // pagination -->	


<!-- // table horizontal -->
<input type="hidden" name="sorttype" id="sorttype" value="<?php if ($_smarty_tpl->getVariable('sSortType')->value==''||$_smarty_tpl->getVariable('sSortType')->value=='asc'){?>asc<?php }else{ ?><?php echo $_smarty_tpl->getVariable('sSortType')->value;?>
<?php }?>"/>
<script type="text/javascript">
	$(function(){
		$("#message_save").fadeOut(2000)
		$("#message_delete").fadeOut(2000)
	})
</script>
</body>
</html>