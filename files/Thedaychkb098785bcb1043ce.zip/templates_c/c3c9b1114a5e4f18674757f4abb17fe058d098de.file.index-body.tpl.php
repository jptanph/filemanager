<?php /* Smarty version Smarty-3.0.6, created on 2011-10-11 14:25:46
         compiled from "templates/index-body.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20365876674e93e16a152bd8-39378444%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3c9b1114a5e4f18674757f4abb17fe058d098de' => 
    array (
      0 => 'templates/index-body.tpl',
      1 => 1318314345,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20365876674e93e16a152bd8-39378444',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>

<div id="pg_thedaychk_wrap1">
	<h4><?php echo $_smarty_tpl->getVariable('sPluginTitle')->value;?>
</h4>
	<div class="pg_thedaychk_wrap2"> 
		<div class="pg_thedaychk_counter_wrap1">
			<div class="pg_thedaychk_counter_wrap2">
				<div id="<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
timer"></div>
				<div class="pg_thedaychk_top_event">
					<?php if (!$_smarty_tpl->getVariable('aResult')->value){?>
						<p>No special event selected.</p>
					<?php }else{ ?>
						<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aResult')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
							<p>This is <?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_title'];?>
 event.</p>
							<input type='hidden' name='<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
start_date' id='<?php echo $_smarty_tpl->getVariable('sPrefix')->value;?>
start_date' value='<?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_date'];?>
'>	
						<?php }} ?>
					<?php }?>
				</div>
			</div>
		</div>
		<div class="pg_thedaychk_events">
			<div class="pg_thedaychk_today_events">
				<dl>
					<?php if (!$_smarty_tpl->getVariable('aScheduleToday')->value){?>
						<dt>No Events Today</dt>
					<?php }else{ ?>
						<dt>Today's Events</dt>
					<?php }?>
					<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aScheduleToday')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
							<dd><?php echo $_smarty_tpl->tpl_vars['rows']->value['month_date'];?>
 - <?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_title'];?>
 </dd>
					<?php }} ?>	
				</dl>
			</div>		
			<div class="pg_thedaychk_upcoming_events">
				<dl>
					<?php if (!$_smarty_tpl->getVariable('aSchedule')->value){?>
						<dt>No Upcoming Events</dt>
					<?php }else{ ?>
						<dt>Upcoming Events</dt>
					<?php }?>
					<?php  $_smarty_tpl->tpl_vars['rows'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('aSchedule')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['rows']->key => $_smarty_tpl->tpl_vars['rows']->value){
?>
							<dd><?php echo $_smarty_tpl->tpl_vars['rows']->value['month_date'];?>
 - <?php echo $_smarty_tpl->tpl_vars['rows']->value['ptd_event_title'];?>
 </dd>
					<?php }} ?>	
				</dl>
			</div>
		</div>
	</div>
</div>