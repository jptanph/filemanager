<?php /* Smarty version Smarty-3.0.6, created on 2011-10-11 12:37:12
         compiled from "templates/index-header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12274418794e93c7f8512cd1-76004911%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22d2c144e4b8d57f2e581bba2f1bd29d198d0db5' => 
    array (
      0 => 'templates/index-header.tpl',
      1 => 1318307832,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12274418794e93c7f8512cd1-76004911',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo $_smarty_tpl->getVariable('sPluginTitle')->value;?>
</title>
	<link href="<?php echo $_smarty_tpl->getVariable('sTemplate')->value;?>
" rel="stylesheet" type="text/css" media="screen" />
	<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryLib')->value;?>
"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJqueryCountdown')->value;?>
"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJSEmulation')->value;?>
"></script>
	<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sJSFront')->value;?>
"></script>
</head>
<body id='PLUGIN_Thedaychk'>