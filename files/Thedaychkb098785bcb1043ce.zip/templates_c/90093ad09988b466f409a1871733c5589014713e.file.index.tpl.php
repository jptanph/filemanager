<?php /* Smarty version Smarty-3.0.6, created on 2011-10-07 09:42:20
         compiled from "templates/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12890489984e8e58fc063cb8-90082584%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '90093ad09988b466f409a1871733c5589014713e' => 
    array (
      0 => 'templates/index.tpl',
      1 => 1317951735,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12890489984e8e58fc063cb8-90082584',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php echo $_smarty_tpl->getVariable('sIndexHeader')->value;?>

<?php echo $_smarty_tpl->getVariable('sIndexBody')->value;?>

<?php echo $_smarty_tpl->getVariable('sIndexFooter')->value;?>
