
jQuery(document).ready(function($){
var Plugin_Thedaychk_front = {
	sServerUrl : 'index.php',
	execStartTimer : function(){
		
		var sStartTime = $("#pg_thedaychk_start_date").val();
		var split_date = sStartTime.split('-');		

		var timer_layout ="<ul class='pg_thedaychk_counter'>"+
		"<li class='pg_thedaychk_days'><dl>"+
			"<dt>DAYS</dt>"+
			"<dd>{d100}</dd><dd>{d10}</dd><dd class='nomarginr'>{d1}</dd>"+
		"</dl></li>"+

		"<li class='pg_thedaychk_time'><dl>"+
			"<dt>HOURS</dt>"+
			"<dd>{h10}</dd><dd class='nomarginr'>{h1}</dd>"+
		"</dl></li>"+
		"<li class='pg_thedaychk_time'><dl>"+
			"<dt>MINS</dt>"+
			"<dd>{m10}</dd><dd class='nomarginr'>{m1}</dd>"+
		"</dl></li>"+
		"<li class='pg_thedaychk_time last'><dl>"+
			"<dt>SECS</dt>"+
			"<dd>{s10}</dd><dd class='nomarginr'>{s1}</dd>"+
		"</dl></li>"+
		"</ul>";
		
		$('#pg_thedaychk_timer').countdown( { until: new Date(split_date[0],split_date[1]-1,split_date[2]), layout: timer_layout,serverSync : this.execGetServerTime, onExpiry : this.execEventExpired } );	
		
	},execGetServerTime : function(){
	
		var start_time = null;
	
		pNode = $("#PLUGIN_Thedaychk");
		mData = { url : Plugin_Thedaychk_front.sServerUrl,
			action:'servertime'
		}				
		PLUGIN.post(pNode, mData , 'custom' , 'html', function (requestContent){
			start_time = new Date(requestContent);
			return start_time;
		});
	},execEventExpired : function(){
		alert(1)
	}
}


Plugin_Thedaychk_front.execStartTimer();
})