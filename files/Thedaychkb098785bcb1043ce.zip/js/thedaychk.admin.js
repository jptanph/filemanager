
var Plugin_Thedaychk_admin = {
	isCheck : 1,
	
	prefix : 'pg_thedaychk_',
	
	sServerUrlContent : 'content.php',
	
	sServerUrlSetup : 'setup.php',
	
	execSaveTemplate : function(){
		var template =  $("input[name="+this.prefix+"template]:checked").val();
		
		$.ajax({
			type:'POST',
			url:this.sServerUrlSetup,
			data:{
				action : 'savetemplate',			
				template : template
			},success : function (serverResponse){
				//alert(Plugin_Thedaychk_admin.sServerUrlSetup)
				window.location.href = Plugin_Thedaychk_admin.sServerUrlSetup+'?status=save';
			}
		})		
	},execReset : function(){
	
		$.ajax({
			type:'POST',
			url:this.sServerUrlSetup,
			data:{
				action : 'savetemplate',			
				template : 'blue'
			},success : function (serverResponse){
				window.location.href = Plugin_Thedaychk_admin.sServerUrlSetup+'?status=restore';
			}
		});
		
	},execAdd : function(){
	
		window.location.href = this.sServerUrlContent+'?action=add';
	
	},execEdit : function(idx){
	
		window.location.href = this.sServerUrlContent+'?action=edit&idx='+idx;
	
	},execSaveEvent : function(){
		
		var event_schedule = $("#schedule_date");
		var event_title = $("#event_title");
		var event_special = $("#event_special").is(":checked");
		var event_recursive = $("#event_recursive").is(":checked");
		var is_special = (event_special==true) ? 1 : 0;
		var is_recursive = (event_recursive==true) ? 1 : 0;
		
		if($.trim(event_title.val())==''){
			event_title.css("border","solid 2px #dc4e22")
			event_title.focus()
		}else{
		
			$.ajax({
				type:'POST',
				url:this.sServerUrlContent,
				data:{
					action : 'saveevent',
					event_schedule : event_schedule.val(),
					event_title : event_title.val(),
					event_special : is_special,
					event_recursive : is_recursive
					
				},success : function (serverResponse){
					window.location.href = Plugin_Thedaychk_admin.sServerUrlContent+'?action=add&status=save';
				}
			});
		}
	},execUpdate : function(){
	
		var event_idx = $("#event_idx");
		var event_schedule = $("#schedule_date");
		var event_title = $("#event_title");
		var event_special = $("#event_special").is(":checked");
		var event_recursive = $("#event_recursive").is(":checked");
		var is_special = (event_special==true) ? 1 : 0;
		var is_recursive = (event_recursive==true) ? 1 : 0;
		if($.trim(event_title.val())==''){
			event_title.css("border","solid 2px #dc4e22")
			event_title.focus()
		}else{
			$.ajax({
				type:'POST',
				url:this.sServerUrlContent,
				data:{
					action : 'updateevent',
					event_schedule : event_schedule.val(),
					event_title : event_title.val(),
					event_special : is_special,
					event_recursive : is_recursive,
					event_idx : event_idx.val()
					
				},success : function (serverResponse){
					window.location.href = Plugin_Thedaychk_admin.sServerUrlContent+"?action=edit&idx="+event_idx.val()+"&status=update";
				}
			});
		}
			
	},execSelectAll : function(){
		
		
		this.isCheck = ( this.isCheck==1 ) ? 0 : 1;
		if(this.isCheck==0){
			$("input[name=pg_thedaychk_check]").attr('checked', true);
		}else{
			$("input[name=pg_thedaychk_check]").attr('checked', false);
		
		}
	},execDelete : function(){
	
		var has_check = $("input[name=pg_thedaychk_check]");
		var check_box =has_check.filter(':checked').length

		if(check_box==0){
			$("#no_del").popUp({width : 400});
		}else{
			$("#confirm_del").popUp({width : 400});
		}
	},execDeleteList : function(){
		$("input[name=pg_thedaychk_check]").each(function(){
				var idx = $(this).val()
				
				if($(this).is(":checked")==true){
					$.ajax({
						type:'POST',
						url:Plugin_Thedaychk_admin.sServerUrlContent,
						data:{
							action : 'deleteevent',
							event_idx : idx
						},success : function (serverResponse){
							window.location.href = Plugin_Thedaychk_admin.sServerUrlContent+'?status=delete';
						}
					});				
				}else{

				}
		});
	},execInitDate : function (default_day){
	
		var sServerUrl = $("#sServerUrl").val();
		thisDate = new Date();
		month = thisDate.getMonth()+1;
		month = (month < 10)? "0"+month : month;
		day 	= thisDate.getDate();
		day = (day < 10)? "0"+day : day;
		year = thisDate.getFullYear();
		currentDate = year + "-" + month + "-" + day;
		$(default_day).val(currentDate)

	},execSort : function(sortField,sortType){
		
		var sortType = $("#sorttype");
		window.location.href = Plugin_Thedaychk_admin.sServerUrlContent+"?sortfield="+sortField+"&sorttype="+sortType.val();
	
	},execSaveContent : function(){
		 $("input[name=pg_thedaychk_event_special]").each(function(){
			var idx = $(this).val()
			
			if($(this).is(":checked")==true)
			{
				$.ajax({
					type:'POST',
					url:Plugin_Thedaychk_admin.sServerUrlContent,
					data:{
						action : 'savecontent',
						idx : idx
					},success : function (serverResponse){
					}
				});
			}
		});
		this.execUpateRecursive();

	},execUpateRecursive : function(){
		 $("input[name=pg_thedaychk_event_recursive]").each(function(){
			var idx = $(this).val()
			var is_checked = $(this).is(":checked");
			$.ajax({
				type : 'POST',
				url : Plugin_Thedaychk_admin.sServerUrlContent,
				data:{
					action : 'saverecursive',
					idx : idx,
					is_checked : is_checked 
				},success : function (serverResponse){
					window.location.href = Plugin_Thedaychk_admin.sServerUrlContent+'?status=save';	
					
				}
			});
		});

	}
}