<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/lib/Common.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/model/model.class.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/common/common.function.php');

class Content_thedaychk
{
	private $_oSmarty;
	private $_oModel;
	private $_sTemplatesFolder;
	private $_iUserIdx;
	private $_sPrefix;
	
	public function __construct()
	{
		$this->_oSmarty = new Smarty();
		$this->_oModel = new Model();
		$this->_iUserIdx = $this->_getUserIdx();
		$this->_sTemplatesFolder = 'templates/';
		$this->_sPrefix = 'pg_thedaychk_';
		$this->_checkTempate();
		$this->_initEnvironment();
		$this->_requestHandler();
		$this->_execList();
	}
	
	private function _initEnvironment()
	{
		$this->_setVariable( 'sPluginRoot' , SERVER_BASE_URL);
		$this->_setVariable( 'sPluginUrl' , PLUGIN_URL);
		$this->_setVariable( 'sJqueryLib' , SERVER_JQUERYJS_URL);
		$this->_setVariable( 'sJqueryUILib' , SERVER_JQUERYUIJS_URL);
		$this->_setVariable( 'sJqueryUICSS' , SERVER_JQUERYUICSS_URL);
		$this->_setVariable( 'sScriptCrossDomain' , CAFE24_CROSS_DOMAIN );
		$this->_setVariable( 'sPrefix' , $this->_sPrefix);
		$this->_setVariable( 'sStatus' , getVar('status'));
	}
	
	private function _getUserIdx()
	{
		return $this->_oModel->getUserIdx(PLUGIN_USER_ID);
	}
	
	private function _requestHandler()
	{
		switch(getVar('action'))
		{
			case'add': $this->_addEvent();
			break;

			case'edit': $this->_viewEvent();
			break;
			
			case'saveevent': $this->_saveEvent();
			break;

			case'updateevent': $this->_updateEvent();
			break;

			case'deleteevent': $this->_deleteEvent();
			break;
			
			case'savecontent': $this->_saveContent();
			break;
			
			case'saverecursive': $this->_saveRecursive();
			break;
			
			default:
				$this->_execList();
				$this->_setTemplate('content.tpl');
		}
	}
	
	private function _execList()
	{	
		$sSortType = ( getVar('sorttype') == 'desc' ) ? 'asc' : 'desc';
		$sSortInput = ( getVar('sorttype') == 'desc' ) ? 'asc' : 'des';
		$this->_setVariable( 'sSortType' , $sSortType);
		$this->_setVariable( 'sSortField' ,  getVar('sortfield'));
		$this->_setVariable( 'sSortInput' , $sSortInput);
		$aResult = $this->_oModel->listEvent($this->_iUserIdx);
		$this->_setVariable( 'iCount' , count($aResult));
		$iCount = 1;
		$aData = array();
		$dateTime = new DateTime();
		$dateTime->format('Y-m-d');
		foreach($aResult as $val)
		{
			if( $val["ptd_recursive_flag"] == 0 && strtotime($dateTime->format($val["ptd_event_date"])) < strtotime($dateTime->format('Y-m-d'))){
				$this->_oModel->deleteEndedEvent($val["ptd_idx"]);
			}
			$aData[] = array(
				"ptd_idx"=>$val["ptd_idx"],
				"ptd_event_title"=>$val["ptd_event_title"],
				"ptd_event_date"=>$val["ptd_event_date"],
				"ptd_specialevent_flag"=>$val["ptd_specialevent_flag"],
				"ptd_recursive_flag"=>$val["ptd_recursive_flag"],
				"row_no"=>$iCount++
			);	
		}
		
		$this->_setVariable( 'aResult' , $aData);
	}
	
	private function _setVariable($sVarName,$sVarValue)
	{
		$this->_oSmarty->assign( $sVarName , $sVarValue);
	}
	
	private function _setTemplate($sTemplate)
	{
		$this->_oSmarty->display($this->_sTemplatesFolder . $sTemplate);
	}
	
	private function _addEvent()
	{
		$aResult = $this->_oModel->listEvent($this->_iUserIdx);
		if(count($aResult)>=6)
		{
			header("Location:content.php");
		}
		else
		{
			$this->_setTemplate('content-add.tpl');
		}
	}

	private function _viewEvent()
	{	
		$aResult = $this->_oModel->viewEvent(getVar('idx'));
		$this->_setVariable( 'aResult' , $aResult);
		$this->_setTemplate('content-edit.tpl');
	}
	
	private function _saveEvent()
	{
		$this->_oModel->insertEvent($this->_iUserIdx);
	}
	
	private function _updateEvent()
	{	
		$this->_oModel->updateEvent($this->_iUserIdx);	
	}

	private function _deleteEvent()
	{
		$this->_oModel->deleteEvent(getVar('event_idx'));
	}
	
	private function _saveContent()
	{
		 $this->_oModel->saveContent($this->_iUserIdx);
	}
	
	private function _saveRecursive()
	{
		$this->_oModel->saveRecursive($this->_iUserIdx);	
	}
	
	private function _checkTempate()
	{
		if($this->_oModel->getTemplate($this->_iUserIdx)==''){
			echo $this->_oModel->insertTemplate('blue',$this->_iUserIdx);
		}else{
			return $this->_oModel->getTemplate($this->_iUserIdx);
		}
	}
}
$contentThedaychk = new Content_thedaychk();