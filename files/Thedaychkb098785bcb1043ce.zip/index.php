<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/lib/Common.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/model/model.class.php');
require(SERVER_DOCUMENT_ROOT . '/plugin/' . PLUGIN_NAME . DS . PLUGIN_VERSION . '/common/common.function.php');

class Index_thedaychk
{
	private $_oSmarty;
	private $_oModel;
	private $_sTemplatesFolder;
	private $_iUserIdx;
	private $_sPrefix;
	
	public function __construct()
	{
		$this->_oSmarty = new Smarty();
		$this->_oModel = new Model();
		$this->_iUserIdx = $this->_getUserIdx();
		$this->_sTemplatesFolder = 'templates/';
		$this->_sPrefix = 'pg_thedaychk_';
		$this->_checkTempate();
		$this->_initEnvironment();
		$this->_requestHandler();
	}
	
	private function _initEnvironment()
	{	
		$this->_setVariable( 'sPluginRoot' , SERVER_BASE_URL);
		$this->_setVariable( 'sPluginUrl' , PLUGIN_URL . 'index.php');
		$this->_setVariable( 'sPluginMainUrl' , PLUGIN_URL);
		$this->_setVariable( 'sJqueryLib' , SERVER_JQUERYJS_URL);
		$this->_setVariable( 'sJqueryUILib' , SERVER_JQUERYUIJS_URL);
		$this->_setVariable( 'sJSEmulation' , SERVER_COMMONJS_URL);
		$this->_setVariable( 'sJqueryUICSS' , SERVER_JQUERYUICSS_URL);
		$this->_setVariable( 'sScriptCrossDomain' , CAFE24_CROSS_DOMAIN );
		$this->_setVariable( 'sPrefix' , $this->_sPrefix);
		$this->_setVariable( 'sStatus' , getVar('status'));
		$this->_setVariable( 'sTemplate' , PLUGIN_URL . 'css/' . $this-> _checkTempate() . '.css');
		$this->_setVariable( 'sJqueryCountdown' , PLUGIN_URL . 'js/jquery.countdown.js');
		$this->_setVariable( 'sJSFront' , PLUGIN_URL . 'js/thedaychk.front.js');
		$this->_setVariable( 'sPluginTitle' ,'The Day Check');
	}
	
	private function _requestHandler()
	{
		switch(getVar('action'))
		{
			case'servertime':
				$this->_execServerTime();
			break;
			default :
				$this->_execSpecial();
				$this-> _execEventUpcoming();
				$this-> _execEventToday();
				$this->_initIndex();
		}
	}
	
	public function _initIndex()
	{
		$sIndexHeader = $this->_fetchTemplate('index-header.tpl');
		$sIndexBody = $this->_fetchTemplate('index-body.tpl');
		$sIndexFooter = $this->_fetchTemplate('index-footer.tpl');
		
		$this->_setVariable('sIndexHeader',$sIndexHeader);
		$this->_setVariable('sIndexBody',$sIndexBody);
		$this->_setVariable('sIndexFooter',$sIndexFooter);
		$this->_setTemplate('index.tpl');
	}
	
	private function _getUserIdx()
	{
		return $this->_oModel->getUserIdx(PLUGIN_USER_ID);
	}
	
	private function _execSpecial()
	{
		$aResult = $this->_oModel->getSpecial($this->_iUserIdx);
		$this->_setVariable('aResult',$aResult);
	}
	
	/** Smarty assign display method. **/
	private function _setVariable($sVarName,$sVarValue)
	{
		$this->_oSmarty->assign( $sVarName , $sVarValue);
	}
	
	/** Smarty display method. **/
	private function _setTemplate($sTemplate)
	{
		$this->_oSmarty->display($this->_sTemplatesFolder . $sTemplate);
	}
	
	/** Smarty fetch method. **/	
	private function _fetchTemplate($sTemplate)
	{
		return $this->_oSmarty->fetch($this->_sTemplatesFolder . $sTemplate);
	}
	
	private function _checkTempate()
	{
		if($this->_oModel->getTemplate($this->_iUserIdx)==''){
			echo $this->_oModel->insertTemplate('blue',$this->_iUserIdx);
		}else{
			return $this->_oModel->getTemplate($this->_iUserIdx);
		}
	}
	
	private function _execCountDown()
	{	
		$aResult = $this->_oModel->getSpecial($this->_iUserIdx);
		$this->_setVariable('aResult',$aResult);
		$this->_setTemplate('index-countdown.tpl');
	}
	
	public function _execEventUpcoming()
	{
		$aResult = $this->_oModel->getEventUpcoming($this->_iUserIdx);
		$this->_setVariable('aSchedule',$aResult);
	}	
	
	public function _execEventToday()
	{
		$aResult = $this->_oModel->getEventToday($this->_iUserIdx);
		$this->_setVariable('aScheduleToday',$aResult);
	}				
	
	public function _execServerTime()
	{
		$dateTimeNow = new DateTime(); 
		echo $dateTimeNow->format("M j, Y H:i:s O"); 
	}
}

$indexThedaychk = new Index_thedaychk();