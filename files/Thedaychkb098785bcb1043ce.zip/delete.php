<?php

// require_once($_SERVER['DOCUMENT_ROOT'] . '/lib/Common.php');
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
require_once($DOCUMENT_ROOT . '/lib/conf.sys.php');

class Uninstall_thedaychk
{
	private $_oUtilDb;
	private $_PG_THEDAYCHK_DATA = 'PG_Thedaychk_data';
	private $_PG_THEDAYCHK_SETTING = 'PG_Thedaychk_setting';
	
	public function __construct()
	{
		$this->_oUtilDb = new utilDb();
		$this->_unInstallThedaychkData();
		$this->_unInstallThedaychkSetting();
	}
	
	private function _unInstallThedaychkData()
	{
		$sSql = "DROP TABLE IF EXISTS `$this->_PG_THEDAYCHK_DATA`";
		$this->_oUtilDb->query($sSql);
	}

	private function _unInstallThedaychkSetting()
	{
		$sSql = "DROP TABLE IF EXISTS `$this->_PG_THEDAYCHK_SETTING`";
		$this->_oUtilDb->query($sSql);
	}	
}
$unInstallThedaychk = new Uninstall_thedaychk;