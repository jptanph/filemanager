<?php

// require_once($_SERVER['DOCUMENT_ROOT'] . '/lib/Common.php');
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
require_once($DOCUMENT_ROOT . '/lib/conf.sys.php');

class Install_thedaychk
{
	private $_oUtilDb;
	
	public function __construct()
	{
		$this->_oUtilDb = new utilDb();
		$this->_installThedaychkData();
		$this->_installThedaychkSetting();
	}
	
	private function _installThedaychkData()
	{
		$sTableStructure = "CREATE TABLE IF NOT EXISTS `PG_Thedaychk_data` (
		`ptd_idx` int(11) NOT NULL auto_increment,
		`ptd_event_title` varchar(30) NOT NULL,
		`ptd_event_date` date NOT NULL,
		`ptd_recursive_flag` int(1) NOT NULL default '0',
		`ptd_specialevent_flag` int(1) NOT NULL default '0',
		`ptd_register_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
		`ptd_pm_idx` int(11) NOT NULL,
		`ptd_front_style` varchar(10) NOT NULL,
		PRIMARY KEY  (`ptd_idx`)
		) ENGINE=InnoDB   DEFAULT CHARSET=latin1";
		
		$this->_oUtilDb->query($sTableStructure);
	}
	
	private function _installThedaychkSetting()
	{
		$sTableStructure = "CREATE TABLE IF NOT EXISTS `PG_Thedaychk_setting` (
		  `pts_idx` int(90) NOT NULL auto_increment,
		  `pts_td_pm_idx` int(90) NOT NULL,
		  `pts_template_color` varchar(90) NOT NULL,
		  PRIMARY KEY  (`pts_idx`)
		) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
		$this->_oUtilDb->query($sTableStructure);
	}
}

$installThedaychk = new Install_thedaychk();