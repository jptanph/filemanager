<?php

/**
 * The day check Model
 * 
 * Database model for the day check plugin
 * 
 * @package    package_name
 * @author     John Adrian Tan <john@simplexi.com>
 * @version    1.0
 * @subpackage   model
 * @link     /model/model.class.php
 */

class Model
{
	private $_oUtilDb;
	private $_PG_THEDAYCHECK_MAIN;
	private $_PG_THEDAYCHECK_DATA;
	private $_PG_THEDAYCHECK_SETTING;
	
	public function __construct()
	{
		$this->_oUtilDb = new utilDb();
		$this->_PG_THEDAYCHECK_MAIN = 'PG_Thedaychk_main';
		$this->_PG_THEDAYCHECK_DATA = 'PG_Thedaychk_data';
		$this->_PG_THEDAYCHECK_SETTING = 'PG_Thedaychk_setting';
	}
	
	public function getUserIdx($sUserId)
	{
		$sSql = "SELECT pm_idx FROM $this->_PG_THEDAYCHECK_MAIN WHERE pm_userid = '$sUserId'";
		$aResult = $this->_oUtilDb->query($sSql,'row');
		return (!$aResult) ? false : $aResult['pm_idx'];
	}
	
	public function getTemplate($iUserIdx)
	{
		$sSql = "SELECT pts_template_color FROM $this->_PG_THEDAYCHECK_SETTING WHERE pts_td_pm_idx = $iUserIdx ";
		$aResult = $this->_oUtilDb->query($sSql,'row');
		return (!$aResult) ? false : $aResult['pts_template_color'];
	}
	
	public function insertTemplate($sTemplatecolor,$iUserIdx)
	{
		$sSql = "INSERT INTO $this->_PG_THEDAYCHECK_SETTING(pts_template_color,pts_td_pm_idx) VALUES('$sTemplatecolor',$iUserIdx)";
		$this->_oUtilDb->query($sSql);
	}
	
	public function updateTemplate($sTemplatecolor,$iUserIdx)
	{
		$sSql = "UPDATE $this->_PG_THEDAYCHECK_SETTING SET pts_template_color = '$sTemplatecolor' WHERE pts_td_pm_idx = $iUserIdx ";
		$this->_oUtilDb->query($sSql);
	}
	
	public function insertEvent($iUserIdx)
	{
		if(getVar('event_special')==1)
		{
			$sSqlData = "UPDATE $this->_PG_THEDAYCHECK_DATA SET ptd_specialevent_flag = 0 WHERE ptd_pm_idx = $iUserIdx";
			$this->_oUtilDb->query($sSqlData);
		}
		
		$aData[] = array("ptd_event_title"=>getVar('event_title'),
					 "ptd_event_date"=>getVar('event_schedule'),
					 "ptd_specialevent_flag"=>getVar('event_special'),
					 "ptd_recursive_flag"=>getVar('event_recursive'),
					 "ptd_pm_idx"=>$iUserIdx
		);
		
		$sSql = $this->_oUtilDb->getInsertQueryLoop( $this->_PG_THEDAYCHECK_DATA, $aData);
		return $this->_oUtilDb->query($sSql);
	}
	
	public function listEvent($iUserIdx )
	{
		$sSort = (getVar('sorttype')=='' && getVar('sortfield')=='') ? ' ORDER BY ptd_recursive_flag DESC' : " ORDER BY " . getVar('sortfield') . ' ' . getVar('sorttype');
		$sSql = "SELECT * FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_pm_idx = $iUserIdx $sSort";
		return $this->_oUtilDb->query($sSql);
		
	}
	
	public function countList($iUserIdx)
	{
		$sSql = "SELECT * FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_pm_idx = $iUserIdx ";
		return $this->_oUtilDb->query($sSql);
	}
	
	public function viewEvent($iUserIdx)
	{
		$sSql = "SELECT * FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_idx = $iUserIdx ";
		return $this->_oUtilDb->query($sSql);
	}

	public function updateEvent($iUserIdx)
	{
		if(getVar('event_special')==1){
			$sSqlData = "UPDATE $this->_PG_THEDAYCHECK_DATA SET ptd_specialevent_flag = 0 WHERE ptd_pm_idx = $iUserIdx";
			$this->_oUtilDb->query($sSqlData);
		}
		
		$aData = array("ptd_event_title"=>getVar('event_title'),
					 "ptd_event_date"=>getVar('event_schedule'),
					 "ptd_specialevent_flag"=>getVar('event_special'),
					 "ptd_recursive_flag"=>getVar('event_recursive')
		);	
		$sWhere = " ptd_idx = " .getVar('event_idx');
		$this->_oUtilDb->update($this->_PG_THEDAYCHECK_DATA, $aData, $sWhere); 
	}
	
	public function deleteEvent($iUserIdx)
	{
		$sSql = "DELETE FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_idx = $iUserIdx";
		$this->_oUtilDb->query($sSql);		
	}
	
	public function getSpecial($iUserIdx)
	{
	    $sSql = "SELECT ptd_event_title,ptd_event_date FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_specialevent_flag = 1 AND ptd_pm_idx = $iUserIdx";
		return $this->_oUtilDb->query($sSql);			
	}
	
	public function getEventUpcoming($iUserIdx)
	{
		
		$sSql = "SELECT DATEDIFF(ptd_event_date,DATE_FORMAT(NOW(),'%Y-%m-%d')) AS date_range,DATE_FORMAT(ptd_event_date,'%M %d') AS month_date,ptd_event_title FROM PG_Thedaychk_data WHERE DATEDIFF(ptd_event_date,DATE_FORMAT(NOW(),'%Y-%m-%d')) > 0 AND ptd_pm_idx = $iUserIdx";
		return $this->_oUtilDb->query($sSql);	
	}
	
	public function getEventToday($iUserIdx)
	{
		$sSql = "SELECT DATEDIFF(ptd_event_date,DATE_FORMAT(NOW(),'%Y-%m-%d')) AS date_range,DATE_FORMAT(ptd_event_date,'%M %d') AS month_date,ptd_event_title FROM PG_Thedaychk_data WHERE DATEDIFF(ptd_event_date,DATE_FORMAT(NOW(),'%Y-%m-%d')) = 0 AND  ptd_pm_idx = $iUserIdx";
		return $this->_oUtilDb->query($sSql);	
	}
	
	public function saveContent($iUserIdx)
	{
		$sSqlData1 = "UPDATE $this->_PG_THEDAYCHECK_DATA SET ptd_specialevent_flag = 0 WHERE ptd_pm_idx = $iUserIdx";
		$sSqlData2 = "UPDATE $this->_PG_THEDAYCHECK_DATA SET ptd_specialevent_flag = 1 WHERE ptd_pm_idx = $iUserIdx AND ptd_idx = " . getVar('idx');
		$this->_oUtilDb->query($sSqlData1);
		$this->_oUtilDb->query($sSqlData2);
	}
	
	public function saveRecursive($iUserIdx)
	{
		$iIsChecked = ( getVar('is_checked') == 'true' ) ? 1 : 0;
		$sSql = "UPDATE $this->_PG_THEDAYCHECK_DATA SET ptd_recursive_flag = $iIsChecked WHERE ptd_pm_idx = $iUserIdx AND ptd_idx = " . getVar('idx');
		$this->_oUtilDb->query($sSql);
	}
	
	public function deleteEndedEvent($iEventIdx)
	{
		$sSql = "DELETE FROM $this->_PG_THEDAYCHECK_DATA WHERE ptd_idx = $iEventIdx";
		$this->_oUtilDb->query($sSql);	
	}
}